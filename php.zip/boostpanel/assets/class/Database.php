<?php
$db = new PDO('mysql:host=localhost;dbname=smurzrvk_elodb', 'smurzrvk_webmaster', 'KTAqOof2q&8L');
?>