<?php session_start();
    require 'Database.php';
	require 'Website.php';
	require 'Redirect.php';
	require 'Booster.php';
	require 'classOrder.php';
	require 'Profile.php';
	require 'Member.php';
	require 'API/php-riot-api.php';
	require 'APIcall.php';
	
?>